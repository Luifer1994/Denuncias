<?php $__env->startSection('content'); ?>
    <tbody>
        <tr>
            <th style="text-align: left; padding-left: 10px;">
                <h2 style="margin-top: 2px;margin-bottom: 2px;">Hola, <?php echo e($msg['name']); ?></h2>
            </th>

        </tr>
        <tr>
            <th style="text-align: left; padding-left: 10px;">
                <p style="margin-top: 2px;margin-bottom: 2px;">
                    Estamos gestionando tu denuncia registrada con código
                    <span style="font-weight: bold; font-size:14px"><?php echo e($msg['cod']); ?></span>,
                </p>
                <br>
                <p style="margin-top: 2px;margin-bottom: 2px;">
                    Puedes realizar seguimiento desde la App con el código
                </p>
                <br>
                <p style="margin-top: 2px;margin-bottom: 2px;">
                    Estado: <span style="font-weight: bold; font-size:14px"><?php echo e($msg['state']); ?></span>

                </p>
                <br>
                <p style="margin-top: 2px;margin-bottom: 2px;">
                    Recuerda que puedes hacer seguimiento a todas tus denuncias directamente desde la app en la
                    sección de buscar y dar seguimiento a denuncias.
                </p>

            </th>

        </tr>
    </tbody>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/luifer/Escritorio/PROYECTO DENUNCIAS/Denuncias/resources/views/emails/change-status.blade.php ENDPATH**/ ?>